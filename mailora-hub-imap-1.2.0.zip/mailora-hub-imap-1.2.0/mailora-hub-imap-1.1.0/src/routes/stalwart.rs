// This module was removed. Any usage should be deleted from routes. Keeping file to avoid missing module errors during refactors.
// compile_error!("stalwart routes are removed; do not use this module");
