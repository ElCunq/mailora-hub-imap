-- Add color column to accounts table
ALTER TABLE accounts ADD COLUMN color TEXT DEFAULT '#3b82f6';
